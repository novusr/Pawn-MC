#include <a_samp>
#define SSCANF_NO_NICE_FEATURES
#include <sscanf2>
#include <streamer>

main() {
    // Your code here
    print("Hello, World!");
    return 0;
}
