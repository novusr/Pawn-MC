#include <a_samp>

public OnFilterScriptInit()
{
    print("FilterScript initialized.");
    new object = CreateObject(1337, 100.0, 200.0, 300.0, 0.0, 0.0, 0.0);
    if (object == INVALID_OBJECT_ID)
    {
        print("Failed to create object.");
        return 0;
    }
    return 1;
}